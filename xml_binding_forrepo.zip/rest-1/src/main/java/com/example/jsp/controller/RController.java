package com.example.jsp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jsp.model.Customer; 

@RestController
public class RController 
{    
	
	  
	
	//@GetMapping(value="/report",  consumes = MediaType.ALL_VALUE, produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	//@RequestMapping(value="/report",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	@GetMapping(value="/report",  consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> showData()
	{ 
		
	     Customer cust=new Customer(101,"raja",123.34f); 
//create parameterize constructor in model class.
//	     private Integer cno;
//	 	private String cname;
//	 	private Float billAmt;
//	 	
//	 	public Customer(int i, String string, float f) {
//	         cno=i;
//	         cname=string;
//	         billAmt=f;
//	 	}
	     //when lombok not working
//	     cust.setCno(102);
//	     cust.setCname("raja");
//	     cust.setBillAmt(102.78f);
		
		
		return new ResponseEntity<Customer>(cust,HttpStatus.OK);
		
	}
}
