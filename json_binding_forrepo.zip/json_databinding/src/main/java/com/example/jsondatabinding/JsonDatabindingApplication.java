package com.example.jsondatabinding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonDatabindingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonDatabindingApplication.class, args);
	}

}
