package com.example.jsondatabinding.controller;

import java.io.IOException;
import java.net.URL;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jsondatabinding.model.CustomerModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;



@RestController
public class BindingController 
{    
	
	@GetMapping(value="/r",  consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CustomerModel> showDatar() throws IOException
	{ 
		ObjectMapper objectMapper = new ObjectMapper();
		
		URL url = new URL("http://localhost:8089/data.json");
		CustomerModel cust=objectMapper.readValue(url, CustomerModel.class); 
		
		return new ResponseEntity<CustomerModel>(cust,HttpStatus.OK);
		
	}
}
