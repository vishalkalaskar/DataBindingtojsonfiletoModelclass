package com.example.request.model;

public class ActorModel 
{
  private Integer aid;
  private String aname;
  private Integer aage;
  private String atype;
  
  public ActorModel(Integer id,String name, Integer age,String type)
  {
	  id=aid;
	  name=aname;
	  age=aage;
	  type=atype;
  }
}
