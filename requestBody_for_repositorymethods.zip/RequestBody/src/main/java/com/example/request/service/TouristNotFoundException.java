package com.example.request.service;

public class TouristNotFoundException extends Exception {

	public TouristNotFoundException(String s) {
		super(s);
	}

}
