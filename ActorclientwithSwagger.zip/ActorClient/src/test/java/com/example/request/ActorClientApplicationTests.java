package com.example.request;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActorClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
